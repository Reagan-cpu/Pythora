# Welcome to Python Code Editor
# Write your Python code here

print('Hello, World!')
