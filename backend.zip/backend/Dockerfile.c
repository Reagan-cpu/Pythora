# Minimal C runtime
FROM gcc:12.2

WORKDIR /app
